from django.shortcuts import render
from .models import Trip

def view_trips(request):
    trips = Trip.objects.all()
    return render(request, 'view_trips.html', {'trips': trips})