from django.contrib.auth.models import User
from django.db import models

class Trip(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=200)  # Местоположение
    image = models.ImageField(upload_to='images/', blank=True, null=True)  # Изображения
    cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)  # Стоимость
    cultural_heritage = models.TextField(blank=True, null=True)  # Места культурного наследия
    places_to_visit = models.TextField(blank=True, null=True)  # Места для посещения
    safety_rating = models.DecimalField(max_digits=2, decimal_places=1, blank=True, null=True)  # Оценка удобства/безопасности

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

