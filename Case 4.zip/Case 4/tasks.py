from django.shortcuts import render
from .models import Book

def view_books(request):
    books = Book.objects.filter(is_available=True)
    return render(request, 'view_books.html', {'books': books})

def sort_books(request):
    category = request.GET.get('category')
    author = request.GET.get('author')
    year = request.GET.get('year')

    books = Book.objects.all()

    if category:
        books = books.filter(category=category)
    if author:
        books = books.filter(author=author)
    if year:
        books = books.filter(year=year)

    return render(request, 'view_books.html', {'books': books})

from datetime import timedelta
from django.utils import timezone

def rent_book(request, book_id):
    if request.method == 'POST':
        book = Book.objects.get(id=book_id)
        duration = request.POST.get('duration')
        
        rent_start = timezone.now()
        rent_end = rent_start
        if duration == '2 weeks':
            rent_end += timedelta(weeks=2)
        elif duration == '1 month':
            rent_end += timedelta(days=30)
        elif duration == '3 months':
            rent_end += timedelta(days=90)
        
        Rental.objects.create(book=book, user=request.user, rent_start=rent_start, rent_end=rent_end, duration=duration)
        book.is_available = False
        book.status = "Rented"
        book.save()
        return redirect('view_books')

def admin_panel(request):
    if request.method == 'POST':
        book_id = request.POST.get('book_id')
        book = Book.objects.get(id=book_id)
        book.price = request.POST.get('price')
        book.is_available = request.POST.get('is_available') == 'on'
        book.save()
    books = Book.objects.all()
    return render(request, 'admin_panel.html', {'books': books})

